//
//  txysec.h
//  aaaa
//
//  Created by aa on 16/11/29.
//  Copyright © 2016年 ytx. All rights reserved.
//

#ifndef txysec_h
#define txysec_h

//加密
char* enc_data_impl(const char* data);
//解密
char* dec_data_impl(const char* data);
#endif /* txysec_h */
